<?php
Class Test{
	public function dbdetails(){
		echo "we are doing custom helper";
	}
}