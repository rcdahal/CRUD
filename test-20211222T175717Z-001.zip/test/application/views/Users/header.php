<html>
<head>
	<title>Article List </title>

	<link rel="stylesheet" href="https://bootswatch.com/5/flatly/bootstrap.min.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>



	</head>
	<body>
		<nav class="navbar navbar-expand-lg navbar-dark bg-info">
      <div class="container-fluid">
    <a class="navbar-brand" href="#">Article List</a>
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor01" style="margin-top:10px;">
      
      <form class="d-flex">
        <input class="form-control me-sm-2" type="text" placeholder="Search" id="myinput">
        <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>

