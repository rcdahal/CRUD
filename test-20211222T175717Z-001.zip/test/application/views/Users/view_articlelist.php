
<?php 
include('header.php');?>


<div class="container" style="margin-top:10px;" id="mytable">

            <?php foreach ($article as $art) :?>
            <h1 align="center"><?=  $art->article_title;?></h1>
            
                        <img src="<?php echo $art->image_path; ?>" alt="" width="100%" height="400">
                        <div align="center">
                            <?=  $art->article_body;?>
                        </div>
                            <div align="right">
                            <?= date('d M y H:i:s',strtotime($art->created_at)); ?>
                        </div>
                    
                    <?php endforeach; /*{$art->id}*/ ?>
                    
                </div>
      

<?php include('footer.php');



?>