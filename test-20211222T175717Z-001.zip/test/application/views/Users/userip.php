<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Use Agent</title>
</head>
<link rel="stylesheet" href="https://bootswatch.com/5/flatly/bootstrap.min.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<body>
	<div class="container" style="margin-top:40px;">
		<h3 align="center">
			Getting IP Of Device
		</h3>
		<div class="table-responsive" style="margin-top:40px;">
			<table class="table table-bordered table-striped ">
				<tr><td><b>Ip Address</b></td>
					<td><?php echo $ip_address;?></td>
				</tr><tr><td><b>Operating System</b></td>
					<td><?php echo $os;?></td>
				</tr><tr><td><b>Browser Details</b></td>
					<td><?php echo $browser.'-'.$browser_version;?></td>
				</tr><tr><td><b>Language</b></td>
					<td><?php echo $en;?></td>
				</tr>
			</table>
		</div>
	</div>

</body>
</html>