
<?php 
include('header.php');?>
<script>
	$(document).ready(function(){
		$("#myinput").on("keyup",function(){
			var value=$(this).val().toLowerCase();
			$("#mytable tr").filter(function(){
				$(this).toggle($(this).text().toLowerCase().indexOf(value)> -1)
			});
		});
	});
</script>
<div class="container">
<a class="btn btn-info" style="margin-top:10px;" href="<?php echo base_url()?>export"?>View Feedback!!</a>
</div>
<div class="container">
<a class="btn btn-danger" style="margin-top:10px;" href="<?php echo base_url()?>dynamic_dependent"?>View Demo!!</a>
</div>
<div class="container">
<a class="btn btn-info" style="margin-left:500px;" href="<?php echo base_url()?>email"?>Check Email Availability!!</a>
</div>
<div class="container">
<a class="btn btn-info" style="margin-left:50px;" href="<?php echo base_url()?>product"?>Get Data In Pdf Format!!</a>
</div>
<div class="container" style="margin-top:10px;">
	<div class="row">
		<div class="col-lg-6">
		<form class="form-inline">
			<input type="search" class="form-control" placeholder="Search" aria-lable="Search" id="myinput">
			<button class="btn btn-outline-success" style="margin-top:10px;" type="submit">Search</button>
		</form>
		</div>
	</div>
	</div>
	<div class="container" style="margin-top:20px">
		<div class="row">
			<h1 align="center">All Articles</h1>
			<table class="table table-bordered">
				<thead>
					<tr>
						<th>S.No</th>
						<th>Article Image</th>
						<th>Article Title</th>
						<th>Published On</th>
					</tr>
				</thead>
				<tbody id="mytable">
					<?php
					if(count($articles)):
					$count=0; 
					?>
					<?php foreach ($articles as $art) :
					
					?>
					<tr>
						<td><?= ++$count;?></td>
						<?php if(!is_null($art->image_path)){?>
							<td><img src="<?php echo $art->image_path; ?>" alt="" width="200" height="200"></td><?php }else{

								?><td><img src="https://localhost/test/upload/Emblem_of_Nepal_(2020)_svg.png" alt="" width="200" height="200"></td><?php }?>
							<td><?= anchor("admin/vew/{$art->id}", $art->article_title);?></td>
							<td><?= date('d M y H:i:s',strtotime($art->created_at)); ?></td>
					</tr>
					<?php endforeach; /*{$art->id}*/ ?>
					<?php else: ?>
						<tr><td colspan="3">Not Data Available</td></tr>
					<?php endif;?>
				</tbody>

			</table>
		</div>
	</div>


<?php include('footer.php');



?>