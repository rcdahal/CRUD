<html>
<head>
	<title>User Details</title>
<body>
	<h1>User Account Details</h1>
	<table>
		<tr>
			<td>First Name</td>
			<td>Account Number</td>
		</tr>
		<?php foreach ($users as $user): ?> 
		<tr>
			<td><?php echo $user['Firstname'];?></td>
			<td><?php echo $user['account'];?></td>
		</tr>
	<?php endforeach; ?>
     	</table>
     </body>
 </head>
 </html>