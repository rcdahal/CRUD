
<?php
	echo anchor('product/generate_pdf', 'Generate PDF Report');
	
	echo '<p/>';

	$this->table->set_heading(...