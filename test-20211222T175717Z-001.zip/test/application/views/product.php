<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Generate PDF Report From MySQL Database Using Codeigniter 3</title>
	<link rel="stylesheet" href="https://bootswatch.com/5/flatly/bootstrap.min.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<style>
		table {
			
			border-collapse: collapse;
			width:100%;
		}
		td, th {
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}
		tr:nth-child(even) {
			background-color: #dddddd;
		}
	</style>
</head>
<body>
	<div style="margin: auto;width: 600px">
		<h3>Sales Information</h3>
		

		<?php
			echo anchor('product/generate_pdf', 'Generate PDF Report') . '</p>';

			//echo anchor('http://localhost:8000/product/generate_pdf', 'Generate PDF Report') . '</p>';

			$this->table->set_heading('Product Id', 'Price', 'Sale Price', 'Sales Count', 'Sale Date');

			foreach ($salesinfo as $sf):
				$this->table->add_row($sf->id, $sf->price, $sf->sale_price, $sf->sales_count, $sf->sale_date);
			endforeach;

			echo $this->table->generate();
		?>

	</div>
	<div class="container">
<a class="btn btn-info" style="margin-left:450px;margin-top:20px;" href="<?php echo base_url()?>product/generate_pdf"?>Get Data In Pdf Format!!</a>
</div>
</body>
</html> 