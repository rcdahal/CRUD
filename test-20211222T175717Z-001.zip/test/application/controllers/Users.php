<?php 
Class Users extends MY_Controller{
	public function Index(){
		/*$this->load->view('Users/homepage');*/
		$this->load->model('loginmodel','ar');
		/*$this->load->library('pagination');
		$config=[
			'base_url'=>
		]*/
		$articles=$this->ar->all_articlelist();
	
		$this->load->view('users/homepage',compact('articles'));

		
	}
	
}