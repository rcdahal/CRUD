<?php 
class user_agent extends CI_Controller{
	function index(){
		$this->load->library('user_agent');
		$data['browser_version']=$this->agent->version();
		$data['browser']=$this->agent->browser();
		$data['os']=$this->agent->platform();
		$data['ip_address']=$this->input->ip_address();
		$data['en']=$this->agent->accept_lang('en');
		$this->load->view('users/userip',$data);

	}
}
?>